.. _utils_examples:

Utils
-------------

Examples concerning the :mod:`iced.utils` module.
