.. _utils:

==============
Utilities
==============

The :mod:`utils` submodule contains utilities function.

.. currentmodule:: iced.utils
